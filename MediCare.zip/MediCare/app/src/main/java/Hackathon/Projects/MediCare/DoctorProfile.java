package Hackathon.Projects.MediCare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DoctorProfile extends AppCompatActivity {
    public static final int PICK_IMAGE = 1;
    TextView EmailDoctor,phoneNumberDoctor;
    FirebaseUser firebaseUser;
    FirebaseAuth firebaseAuth;
    Button Upload;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);
        EmailDoctor=findViewById(R.id.EmailDoctor);
        imageView=findViewById(R.id.cerificate);
        Upload=findViewById(R.id.uploadVerification);
        phoneNumberDoctor=findViewById(R.id.phoneNumberDoctor);
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseUser=firebaseAuth.getCurrentUser();
        assert firebaseUser != null;
        EmailDoctor.setText(firebaseUser.getEmail());
        phoneNumberDoctor.setText(firebaseUser.getPhoneNumber());
        Upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(imageBitmap);
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        }
    }
}
