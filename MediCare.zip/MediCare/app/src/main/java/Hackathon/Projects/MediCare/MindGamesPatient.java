package Hackathon.Projects.MediCare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MindGamesPatient extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mind_games_patient);
    }
}
