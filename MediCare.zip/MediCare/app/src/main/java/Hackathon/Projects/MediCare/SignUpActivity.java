package Hackathon.Projects.MediCare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;

public class SignUpActivity extends AppCompatActivity {
    //Widgets
    EditText phoneNumber, Email, password;
    Button SignUp;
    TextView SignIn;
    //Vars
    FirebaseAuth mAuth;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBacks;
    PhoneAuthProvider phoneAuthProvider;
    String PhoneNumber, EmailID, passwordSignUp, VERIFICATION_ID;
    private static final String TAG = "SignUpActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        phoneAuthProvider = PhoneAuthProvider.getInstance();
        phoneNumber = findViewById(R.id.phoneNumberSignup);
        Email = findViewById(R.id.usernameSignUp);
        SignUp = findViewById(R.id.SignUp);
        SignIn = findViewById(R.id.signIn);
        password = findViewById(R.id.passwordSignUp);
        mAuth = FirebaseAuth.getInstance();
        signInClicked();
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PhoneNumber = phoneNumber.getText().toString().trim();
                EmailID = Email.getText().toString().toLowerCase().trim();
                passwordSignUp = password.getText().toString().trim();
                if (TextUtils.isEmpty(EmailID) || TextUtils.isEmpty(passwordSignUp) || TextUtils.isEmpty(PhoneNumber)) {
                    Toast.makeText(SignUpActivity.this, "Please Enter All Fields", Toast.LENGTH_SHORT).show();
                    phoneNumber.requestFocus();
                } else {
                    signUpAuthentication();
                }
            }
        });
    }
    private void signUpAuthentication() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing");
        progressDialog.show();
        mAuth.createUserWithEmailAndPassword(EmailID, passwordSignUp).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    progressDialog.dismiss();
                    Toast.makeText(SignUpActivity.this, "Registered SuccessFully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(SignUpActivity.this,MainActivity.class);
                    finish();
                    startActivity(intent);

                } else {
                    progressDialog.dismiss();
                    Toast.makeText(SignUpActivity.this, "Something is Wrong; Registration Failed", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void signInClicked() {
        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

}